<!DOCTYPE html>
<meta charset="UTF-8">
<html lang=”pt-BR”>
  <head>
    <title>Exercício 3</title> 
  </head>
<body>
  <?php
  
	$ano_nascimento = 1999;
	$ano_atual      = 2017;
	$idade_anos     = $ano_atual - $ano_nascimento;
	$idade_meses    = $idade_anos * 12;
	$idade_dias     = $idade_anos * 365;
	$idade_semanas  = $idade_dias / 7;
	$idade_semanas  = floor($idade_semanas);
	// a funcao floor() arredonda o numero para baixo
	// poderia usar a funcao ceil() para arredondar para cima
	
	echo "A idade da pessoa em anos é $idade_anos <br>";
	echo "A idade da pessoa em meses é $idade_meses <br>";
	echo "A idade da pessoa em dias é $idade_dias <br>";
	echo "A idade da pessoa em semanas é $idade_semanas <br>";
	
	
			
  ?>
</body>
</html>