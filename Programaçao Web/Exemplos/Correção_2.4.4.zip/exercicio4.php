<!DOCTYPE html>
<meta charset="UTF-8">
<html lang=”pt-BR”>
  <head>
    <title>Exercício 4</title> 
  </head>
<body>
  <?php
  
	$deposito    = 4000.0;
	$taxa_juros  = 0.0067; // 0.67 /100 ou 0.67 porcento
	$rendimento  = $deposito * $taxa_juros;
	$valor_total = $deposito + $rendimento;
	
	echo "O rendimento após um mês é de R\$ $rendimento <br>";
	echo "O valor total depois do rendimento é R\$ $valor_total";
	
  ?>
</body>
</html>