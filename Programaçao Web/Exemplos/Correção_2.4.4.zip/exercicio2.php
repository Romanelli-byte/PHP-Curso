<!DOCTYPE html>
<meta charset="UTF-8">
<html lang=”pt-BR”>
  <head>
    <title>Exercício 2</title> 
  </head>
<body>
  <?php
  
	$prova1  = 9.0;
	$prova2  = 7.5;
	$projeto = 6.0;
	
	$nf = (0.3 * $prova1) + (0.4 * $prova2) + (0.3 * $projeto);
		
	echo "A nota final do aluno no semestre é $nf";
			
  ?>
</body>
</html>