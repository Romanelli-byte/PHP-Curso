<!DOCTYPE html>
<meta charset="UTF-8">
<html lang=”pt-BR”>
  <head>
    <title>Exercício 1</title> 
  </head>
<body>
  <?php
  
	$salario = 1500.0 + (0.04 * 10000.0);
		
	echo "O salário do funcionário é $salario";
			
  ?>
</body>
</html>