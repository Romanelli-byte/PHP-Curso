<!DOCTYPE html>
<meta charset="UTF-8">
<html lang=”pt-BR”>
  <head>
    <title>Exercício 5</title> 
  </head>
<body>
  <?php
  
	$salario_minimo = 937.0;
	$valor_hora     = $salario_minimo * 0.05;
	$salario_bruto  = 12 * $valor_hora;
	$salario_final  = $salario_bruto - (0.03 * $salario_bruto);
	$salario_final = number_format($salario_final, 2); // formata o numero para ter dois digitos apos o ponto
	
	echo "O garçom irá receber R\$ $salario_final";
			
  ?>
</body>
</html>